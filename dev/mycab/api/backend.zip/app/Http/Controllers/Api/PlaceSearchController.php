<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

class PlaceSearchController extends Controller
{
    private const NOMINATIM_BASE = 'https://nominatim.openstreetmap.org';

    private function nominatimHttp(): PendingRequest
    {
        return Http::timeout(12)
            ->withOptions([
                'verify' => config('services.nominatim.ssl_verify', true),
            ])
            ->withHeaders([
                'User-Agent' => (string) config('services.nominatim.user_agent'),
                'Accept-Language' => 'en,hi',
            ]);
    }

    /**
     * Forward geocode: address / place text → suggestions (OpenStreetMap Nominatim).
     * Proxied server-side for CORS and a valid User-Agent per usage policy.
     *
     * @see https://operations.osmfoundation.org/policies/nominatim/
     */
    public function search(Request $request): JsonResponse
    {
        $q = trim((string) $request->query('q', ''));
        if (mb_strlen($q) < 2) {
            return response()->json([]);
        }

        $cacheKey = 'places:search:'.md5(mb_strtolower($q));

        $mapped = Cache::remember($cacheKey, now()->addMinutes(30), function () use ($q) {
            $response = $this->nominatimHttp()->get(self::NOMINATIM_BASE.'/search', [
                'q' => $q,
                'format' => 'json',
                'limit' => 8,
                'addressdetails' => 1,
            ]);

            if (! $response->successful()) {
                return [];
            }

            $rows = $response->json();
            if (! is_array($rows)) {
                return [];
            }

            return collect($rows)->map(function (array $item) {
                $lat = isset($item['lat']) ? (float) $item['lat'] : null;
                $lng = isset($item['lon']) ? (float) $item['lon'] : null;
                $label = $item['display_name'] ?? '';

                if ($label === '' || $lat === null || $lng === null) {
                    return null;
                }

                return [
                    'label' => $label,
                    'lat' => $lat,
                    'lng' => $lng,
                ];
            })->filter()->values()->all();
        });

        return response()->json($mapped);
    }

    /**
     * Reverse geocode: GPS coordinates → single address line.
     */
    public function reverse(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'lat' => ['required', 'numeric', 'between:-90,90'],
            'lng' => ['required', 'numeric', 'between:-180,180'],
        ]);

        $lat = (float) $validated['lat'];
        $lng = (float) $validated['lng'];
        $cacheKey = 'places:reverse:'.round($lat, 5).'_'.round($lng, 5);

        $cached = Cache::get($cacheKey);
        if (is_array($cached)) {
            return response()->json($cached);
        }

        $response = $this->nominatimHttp()->get(self::NOMINATIM_BASE.'/reverse', [
            'lat' => $lat,
            'lon' => $lng,
            'format' => 'json',
            'zoom' => 18,
        ]);

        if (! $response->successful()) {
            return response()->json(['message' => 'Could not resolve location'], 422);
        }

        $item = $response->json();
        if (! is_array($item)) {
            return response()->json(['message' => 'Could not resolve location'], 422);
        }

        $label = $item['display_name'] ?? null;
        if (! is_string($label) || $label === '') {
            return response()->json(['message' => 'Could not resolve location'], 422);
        }

        $rlat = isset($item['lat']) ? (float) $item['lat'] : $lat;
        $rlng = isset($item['lon']) ? (float) $item['lon'] : $lng;

        $payload = [
            'label' => $label,
            'lat' => $rlat,
            'lng' => $rlng,
        ];

        Cache::put($cacheKey, $payload, now()->addHours(24));

        return response()->json($payload);
    }
}
