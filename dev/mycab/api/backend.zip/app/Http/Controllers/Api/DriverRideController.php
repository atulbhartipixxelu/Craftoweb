<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Driver;
use App\Models\Ride;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class DriverRideController extends Controller
{
    /**
     * Logged-in driver's profile (linked `drivers` row).
     */
    public function me(Request $request): JsonResponse
    {
        $driver = $this->resolveDriver($request);

        return response()->json([
            'user' => $request->user(),
            'driver' => $driver,
        ]);
    }

    /**
     * Update driver profile (text fields + optional avatar image). Syncs linked `users` row for name/email/phone.
     */
    public function updateProfile(Request $request): JsonResponse
    {
        $driver = $this->resolveDriver($request);
        $user = $request->user();

        $validated = $request->validate([
            'name' => ['sometimes', 'string', 'max:255'],
            'phone' => ['sometimes', 'string', 'max:32', Rule::unique('users', 'phone')->ignore($user->id)],
            'email' => ['sometimes', 'string', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'vehicle_type' => ['sometimes', 'string', 'in:mini,sedan,suv'],
            'plate_number' => ['sometimes', 'string', 'max:32', Rule::unique('drivers', 'plate_number')->ignore($driver->id)],
            'avatar' => ['nullable', 'image', 'max:4096'],
        ]);

        if ($request->hasFile('avatar')) {
            if ($driver->avatar) {
                Storage::disk('public')->delete($driver->avatar);
            }
            $validated['avatar'] = $request->file('avatar')->store('driver-avatars', 'public');
        }

        $userFields = array_intersect_key($validated, array_flip(['name', 'email', 'phone']));
        if ($userFields !== []) {
            $user->update($userFields);
        }

        $driverFields = array_intersect_key($validated, array_flip(['name', 'email', 'phone', 'vehicle_type', 'plate_number', 'avatar']));
        if ($driverFields !== []) {
            $driver->update($driverFields);
        }

        $driver->refresh();

        return response()->json([
            'user' => $user->fresh(),
            'driver' => $driver,
            'message' => 'Profile updated',
        ]);
    }

    /**
     * Rides assigned to this driver (newest first).
     */
    public function index(Request $request): JsonResponse
    {
        $driver = $this->resolveDriver($request);

        $rides = Ride::query()
            ->where('driver_id', $driver->id)
            ->with('user')
            ->orderByDesc('created_at')
            ->get();

        return response()->json($rides);
    }

    private function resolveDriver(Request $request): Driver
    {
        abort_unless($request->user()->role === 'driver', 403, 'Only drivers can access this resource.');

        /** @var Driver|null $driver */
        $driver = Driver::query()->where('user_id', $request->user()->id)->first();

        abort_if($driver === null, 404, 'Driver profile not found. Complete registration or contact support.');

        return $driver;
    }
}
