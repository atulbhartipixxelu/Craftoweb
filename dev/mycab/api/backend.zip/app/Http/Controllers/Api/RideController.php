<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Driver;
use App\Models\Ride;
use App\Services\RideBookingNotifier;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RideController extends Controller
{
    /**
     * Active bookings for the authenticated passenger.
     */
    public function index(Request $request): JsonResponse
    {
        abort_unless($request->user()->role === 'passenger', 403, 'Passenger account required.');

        $rides = Ride::query()
            ->where('user_id', $request->user()->id)
            ->with(['driver', 'user'])
            ->orderByDesc('created_at')
            ->get();

        return response()->json($rides);
    }

    /**
     * Book a new ride.
     */
    public function store(Request $request): JsonResponse
    {
        abort_unless($request->user()->role === 'passenger', 403, 'Passenger account required to book a ride.');

        $validated = $request->validate([
            'pickup_address' => ['required', 'string', 'max:500'],
            'dropoff_address' => ['required', 'string', 'max:500'],
            'pickup_lat' => ['nullable', 'numeric'],
            'pickup_lng' => ['nullable', 'numeric'],
            'dropoff_lat' => ['nullable', 'numeric'],
            'dropoff_lng' => ['nullable', 'numeric'],
            'vehicle_type' => ['required', 'string', 'in:mini,sedan,suv'],
        ]);

        $distanceKm = $this->resolveDistanceKm($validated);

        $fare = $this->estimateFare($validated['vehicle_type'], $distanceKm);

        $ride = Ride::query()->create([
            'user_id' => $request->user()->id,
            'pickup_address' => $validated['pickup_address'],
            'dropoff_address' => $validated['dropoff_address'],
            'pickup_lat' => $validated['pickup_lat'] ?? null,
            'pickup_lng' => $validated['pickup_lng'] ?? null,
            'dropoff_lat' => $validated['dropoff_lat'] ?? null,
            'dropoff_lng' => $validated['dropoff_lng'] ?? null,
            'vehicle_type' => $validated['vehicle_type'],
            'status' => 'pending',
            'distance_km' => $distanceKm,
            'fare_estimate' => $fare,
        ]);

        $this->tryAssignDriver($ride);

        $ride->refresh()->load(['driver', 'user']);

        $notifications = app(RideBookingNotifier::class)->sendEmails($ride);

        $payload = $ride->toArray();
        $payload['notifications'] = $notifications;

        return response()->json($payload, 201);
    }

    /**
     * Single ride details.
     */
    public function show(Request $request, string $id): JsonResponse
    {
        abort_unless($request->user()->role === 'passenger', 403, 'Passenger account required.');

        $ride = Ride::query()->with(['driver', 'user'])->findOrFail($id);

        if ($ride->user_id !== $request->user()->id) {
            abort(403);
        }

        return response()->json($ride);
    }

    /**
     * Cancel a ride that has not finished yet.
     */
    public function cancel(Request $request, Ride $ride): JsonResponse
    {
        abort_unless($request->user()->role === 'passenger', 403, 'Passenger account required.');

        if ($ride->user_id !== $request->user()->id) {
            abort(403);
        }

        if (! in_array($ride->status, ['pending', 'accepted', 'in_progress'], true)) {
            return response()->json(['message' => 'This ride cannot be cancelled'], 422);
        }

        if ($ride->driver_id) {
            Driver::query()->whereKey($ride->driver_id)->update(['is_available' => true]);
        }

        $ride->update(['status' => 'cancelled']);

        $ride->load(['driver', 'user']);

        return response()->json($ride);
    }

    /**
     * @param  array<string, mixed>  $validated
     */
    private function resolveDistanceKm(array $validated): float
    {
        $plat = $validated['pickup_lat'] ?? null;
        $plng = $validated['pickup_lng'] ?? null;
        $dlat = $validated['dropoff_lat'] ?? null;
        $dlng = $validated['dropoff_lng'] ?? null;

        if ($plat !== null && $plng !== null && $dlat !== null && $dlng !== null) {
            return round($this->haversineKm((float) $plat, (float) $plng, (float) $dlat, (float) $dlng), 2);
        }

        return 5.0;
    }

    private function haversineKm(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $earthKm = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2
            + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;

        return $earthKm * (2 * atan2(sqrt($a), sqrt(1 - $a)));
    }

    private function estimateFare(string $vehicleType, float $distanceKm): float
    {
        $base = match ($vehicleType) {
            'mini' => 49,
            'sedan' => 69,
            'suv' => 99,
            default => 59,
        };

        return round($base + $distanceKm * 14, 2);
    }

    private function tryAssignDriver(Ride $ride): void
    {
        $driver = Driver::query()
            ->where('is_available', true)
            ->where('vehicle_type', $ride->vehicle_type)
            ->orderByRaw('case when user_id is not null then 0 else 1 end')
            ->orderBy('id')
            ->first();

        if (! $driver) {
            return;
        }

        $driver->update(['is_available' => false]);
        $ride->update([
            'driver_id' => $driver->id,
            'status' => 'accepted',
        ]);
    }
}
