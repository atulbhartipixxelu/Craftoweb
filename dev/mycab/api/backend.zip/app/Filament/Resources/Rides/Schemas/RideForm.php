<?php

namespace App\Filament\Resources\Rides\Schemas;

use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class RideForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Select::make('user_id')
                    ->relationship('user', 'name')
                    ->searchable()
                    ->preload()
                    ->required(),
                Select::make('driver_id')
                    ->relationship('driver', 'name')
                    ->searchable()
                    ->preload(),
                TextInput::make('pickup_address')
                    ->required()
                    ->maxLength(500),
                TextInput::make('dropoff_address')
                    ->required()
                    ->maxLength(500),
                TextInput::make('pickup_lat')
                    ->numeric(),
                TextInput::make('pickup_lng')
                    ->numeric(),
                TextInput::make('dropoff_lat')
                    ->numeric(),
                TextInput::make('dropoff_lng')
                    ->numeric(),
                Select::make('vehicle_type')
                    ->options([
                        'mini' => 'Mini',
                        'sedan' => 'Sedan',
                        'suv' => 'SUV',
                    ])
                    ->required(),
                Select::make('status')
                    ->options([
                        'pending' => 'Pending',
                        'accepted' => 'Accepted',
                        'in_progress' => 'In progress',
                        'completed' => 'Completed',
                        'cancelled' => 'Cancelled',
                    ])
                    ->required()
                    ->default('pending'),
                TextInput::make('distance_km')
                    ->numeric(),
                TextInput::make('fare_estimate')
                    ->required()
                    ->numeric(),
            ]);
    }
}
