<?php

namespace App\Filament\Resources\Drivers\Schemas;

use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Schema;

class DriverForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                FileUpload::make('avatar')
                    ->label('Profile photo')
                    ->image()
                    ->disk('public')
                    ->directory('driver-avatars')
                    ->imageEditor()
                    ->maxSize(4096)
                    ->columnSpanFull(),
                TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                TextInput::make('phone')
                    ->tel()
                    ->required()
                    ->maxLength(32),
                TextInput::make('email')
                    ->label('Email address')
                    ->email()
                    ->maxLength(255),
                Select::make('vehicle_type')
                    ->options([
                        'mini' => 'Mini',
                        'sedan' => 'Sedan',
                        'suv' => 'SUV',
                    ])
                    ->required(),
                TextInput::make('plate_number')
                    ->required()
                    ->maxLength(32),
                Toggle::make('is_available')
                    ->label('Available for new rides')
                    ->default(true),
                TextInput::make('latitude')
                    ->numeric(),
                TextInput::make('longitude')
                    ->numeric(),
                Select::make('user_id')
                    ->label('Linked user')
                    ->relationship('user', 'email')
                    ->searchable()
                    ->preload()
                    ->nullable(),
            ]);
    }
}
