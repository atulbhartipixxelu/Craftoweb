<?php echo e($slot); ?>

<?php /**PATH E:\himcab\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>